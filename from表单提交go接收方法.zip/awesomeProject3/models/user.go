package models
import (
	"awesomeProject3/utils"
	"fmt"
)
type User struct { //定义一个模型以免需要写sql语句
	Id int
	Username string
	Password string
	CreaTime int64
}
func InsertUser(user *User)(int64,error)  {
	sql:="insert into user(username,password,createtime)values(?,?,?)"
	return utils.ExecSQL(sql,user.Username,user.Password,user.CreaTime)
}
func QueryUserWithUsername(username string)int  {
	sql:=fmt.Sprintf("select id from user where username=%s",username)//通过用户名查询id是否存在如果在的话返回的id判断为真则表示用户已存在
	row:=utils.QueryRowDB(sql)
	id:=0
	_=row.Scan(&id) //扫码下结果赋值给id
	return id
}