package utils
import (
	"database/sql"
	_"github.com/go-sql-driver/mysql" //导入mysql的包才可以使用mysql
	)
var db *sql.DB
func InitMySQL() error{
	if db==nil{
		db0,err:=sql.Open("mysql","root:GuYuePass666!@tcp(192.168.58.10:3306)/productgo")
		if err!=nil{
			return err
		}
		db=db0
		//初始化user表
		err=InitTableUser()
		if err!=nil{
			return err
		}
	}
	return nil
}
func InitTableUser() error {
	sql:=`CREATE TABLE IF NOT EXISTS user(
		id INT(10) PRIMARY KEY AUTO_INCREMENT NOT NULL,
        username VARCHAR(64),
        password VARCHAR(64),
        createtime int(10)
	);`
	if _,err:=ExecSQL(sql);err!=nil{
		return err
	}
	return nil
}
func ExecSQL(sql string,args ...interface{})(int64,error)  {
	result,err:=db.Exec(sql,args...) //增删改查
	if err!=nil{
		return 0,err
	}
	count,err:=result.RowsAffected()
	if err!=nil{
		return 0,err
	}
	return count,nil
}
func QueryRowDB(sql string) *sql.Row  {
	return db.QueryRow(sql) //这个是数据库链接之后的功能我们这里是调方法
}