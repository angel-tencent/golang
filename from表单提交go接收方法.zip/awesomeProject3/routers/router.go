package routers

import (
	"awesomeProject3/controllers"
	"github.com/astaxie/beego"
)

func init()  {
	beego.Router("/",&controllers.MainController{})
	beego.Router("/login",&controllers.LoginController{}) //这个在user里面引用
	beego.Router("/register",&controllers.RegsterController{})
}
