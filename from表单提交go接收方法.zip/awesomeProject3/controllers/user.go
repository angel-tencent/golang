package controllers
import (
	"awesomeProject3/models"
	"fmt"
	"github.com/astaxie/beego"
	"time"
)
type LoginController struct {
	beego.Controller
}
//登录相关
func (l *LoginController) Get()  { //这个函数的指向有get方法
	l.TplName="login.html" //关联登录页面hml
}
//注册相关
type RegsterController struct {
	beego.Controller
}
//登录相关
func (r *RegsterController) Get()  {
	r.TplName="register.html" //关联注册页面html
}
func (r *RegsterController) Post() {
	username:=r.GetString("username") //获取js传过来的数据
	password:=r.GetString("password")
	repassword:=r.GetString("repassword")
	fmt.Println(username,password,repassword) //测试下看数据有没有过来
	//注册之前先判断下用户名是否已存在
	id:=models.QueryUserWithUsername(username)
	if id>0{
		r.Data["json"]=map[string]interface{}{
			"code":0,
			"message":"用户名已存在",
		}
		r.ServeJSON()
		return
	}
	//用户名不存在,添加到数据库里
	user:=models.User{0,username,password,time.Now().Unix()}
	_,err:=models.InsertUser(&user)
	if err!=nil{
		r.Data["json"]=map[string]interface{}{
			"code":0,
			"message":"注册失败",
		}
	}else {
		r.Data["json"]=map[string]interface{}{
			"code":1,
			"message":"注册成功",
		}
	}
	r.ServeJSON()
}