package main
import (
	"awesomeProject3/utils"
	"github.com/astaxie/beego"
)
func main() {
	if err:=utils.InitMySQL();err!=nil{
		panic(err)
	}
	beego.Run()
}